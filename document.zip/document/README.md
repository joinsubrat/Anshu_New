Instructions to the start the Well-wellbore service
=========================================
Note: In the swagger UI you, for all REST API tries ensure 'Response Content Type' is 'application/json' 

##To Install lombak in eclipse, please follow the below steps. if you not install you may see compile errors in code.

1) Download Lombok Jar File, org.projectlombok.lombok.1.16.18.jar

2) Once the jar downloaded in Local repository, goto the jar location from command prompt and run the 
	following command java -jar lombok-1.16.18.jar and we should be greeted by Lombok installation window provided by lombok
	
3) Now click on the "Specify Location" button and locate the eclipse.exe path under eclipse installation folder

4) Now we need to finally install this by clicking the "Install/Update" button, and once install complete, click "Quit Installer" or close the window.

5) Finally do mvn clean install on the project.

6) Exit and Start eclipse/STS

7) eclipse menu -> project ->  clean -> click